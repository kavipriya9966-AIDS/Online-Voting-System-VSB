let userId = "";

function register() {
    fetch("/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            username: username.value,
            password: password.value
        })
    }).then(res => res.text()).then(alert);
}

function login() {
    fetch("/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            username: username.value,
            password: password.value
        })
    })
    .then(res => res.json())
    .then(data => {
        userId = data._id;
        localStorage.setItem("userId", userId);
        window.location = "vote.html";
    });
}

function loadCandidates() {
    fetch("/candidates")
    .then(res => res.json())
    .then(data => {
        const div = document.getElementById("candidates");
        data.forEach(c => {
            div.innerHTML += `
                <p>${c.name} 
                <button onclick="vote('${c._id}')">Vote</button></p>
            `;
        });
    });
}

function vote(id) {
    fetch("/vote", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            userId: localStorage.getItem("userId"),
            candidateId: id
        })
    }).then(res => res.text()).then(alert);
}

if (window.location.pathname.includes("vote.html")) {
    loadCandidates();
}