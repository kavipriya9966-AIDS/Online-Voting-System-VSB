const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static("public"));

mongoose.connect("mongodb://127.0.0.1:27017/votingDB")
.then(() => console.log("MongoDB Connected"))
.catch(err => console.log(err));

const User = require("./models/User");
const Candidate = require("./models/Candidate");

app.post("/register", async (req, res) => {
    const user = new User(req.body);
    await user.save();
    res.send("User Registered");
});

app.post("/login", async (req, res) => {
    const user = await User.findOne(req.body);
    if (user) res.send(user);
    else res.send("Invalid");
});

app.get("/candidates", async (req, res) => {
    const candidates = await Candidate.find();
    res.json(candidates);
});

app.post("/vote", async (req, res) => {
    const { userId, candidateId } = req.body;

    const user = await User.findById(userId);
    if (user.voted) return res.send("Already Voted");

    await Candidate.findByIdAndUpdate(candidateId, { $inc: { votes: 1 } });
    user.voted = true;
    await user.save();

    res.send("Vote Successful");
});

app.listen(3000, () => console.log("Server running on port 3000"));