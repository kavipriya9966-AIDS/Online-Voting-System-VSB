namespace OnlineVotingApp.Presentation;

[Uno.Extensions.Reactive.ReactiveBindable(false)]
public partial record CandidatesModel
{
    public string PageTitle { get; } = "Candidates";
    public string TotalCandidates { get; } = "18";
    public string FeaturedElection { get; } = "Presidential General Election 2026";

    public IReadOnlyList<CandidateGroup> Groups { get; } = new[]
    {
        new CandidateGroup("Presidential General Election 2026", "National", "Active", new[]
        {
            new Candidate("c-001", "e-001", "Margaret Elaine Hartley", "Democratic Alliance", "President", "Former Secretary of State with 30 years in public service. Committed to healthcare reform and climate policy.", 51200, "45.5%", ""),
            new Candidate("c-002", "e-001", "Robert James Caldwell", "National Progress Party", "President", "Two-term Senator and decorated military veteran advocating for economic growth and border security.", 43800, "38.9%", ""),
            new Candidate("c-003", "e-001", "Priya Anand", "Green Future Coalition", "President", "Environmental scientist turned politician. Champion of renewable energy and education equity.", 17450, "15.5%", ""),
        }),
        new CandidateGroup("City Council District 4", "Local", "Active", new[]
        {
            new Candidate("c-004", "e-002", "Carlos Rivera", "Citizens First", "Councillor", "15-year resident and small business owner fighting for neighborhood investment and safer streets.", 2800, "45.2%", ""),
            new Candidate("c-005", "e-002", "Sophie Laurent", "Progressive Alliance", "Councillor", "Urban planner with expertise in affordable housing and sustainable development.", 2100, "33.9%", ""),
            new Candidate("c-006", "e-002", "James Okafor", "Independent", "Councillor", "Retired police captain focused on community policing and youth programs.", 1300, "21.0%", ""),
        }),
        new CandidateGroup("Referendum: Public Transit Expansion", "Regional", "Active", new[]
        {
            new Candidate("c-007", "e-003", "Yes — Support Transit Bill", "Coalition for Mobility", "Referendum", "Support the $2.4B investment for expanded rail and bus rapid transit across the region.", 17600, "55.3%", ""),
            new Candidate("c-008", "e-003", "No — Oppose Transit Bill", "Taxpayers Alliance", "Referendum", "Oppose new transit funding citing fiscal concerns and alternative infrastructure priorities.", 14200, "44.7%", ""),
        }),
    };
}

public partial record CandidateGroup(
    string ElectionTitle,
    string Category,
    string ElectionStatus,
    IReadOnlyList<Candidate> Candidates);
