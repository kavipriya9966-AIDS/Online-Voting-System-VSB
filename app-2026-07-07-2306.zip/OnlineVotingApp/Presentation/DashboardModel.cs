namespace OnlineVotingApp.Presentation;

[Uno.Extensions.Reactive.ReactiveBindable(false)]
public partial record DashboardModel
{
    public string WelcomeMessage { get; } = "Welcome, Jordan Ellis";
    public string UserRole { get; } = "Registered Voter";
    public string TotalElections { get; } = "12";
    public string ActiveElections { get; } = "3";
    public string ElectionsClosed { get; } = "9";
    public string VotesCastToday { get; } = "14,832";
    public string SystemStatus { get; } = "All Systems Operational";
    public bool IsSystemHealthy { get; } = true;
    public IReadOnlyList<Election> ActiveElections_List { get; } = new[]
    {
        new Election("e-001", "Presidential General Election 2026", "Cast your vote for the President of the Republic.", "Active", "Active", new DateOnly(2026, 3, 1), new DateOnly(2026, 3, 31), 240000, 112450, "46.9%", "National"),
        new Election("e-002", "City Council District 4", "Elect your local City Council representative for District 4.", "Active", "Active", new DateOnly(2026, 3, 10), new DateOnly(2026, 3, 25), 18400, 6200, "33.7%", "Local"),
        new Election("e-003", "Referendum: Public Transit Expansion", "Vote on the proposed public transit infrastructure bill.", "Active", "Active", new DateOnly(2026, 3, 15), new DateOnly(2026, 4, 5), 95000, 31800, "33.5%", "Regional"),
    };
    public IReadOnlyList<Election> RecentElections { get; } = new[]
    {
        new Election("e-004", "School Board Election 2025", "Elect members for the regional school board.", "Closed", "Closed", new DateOnly(2025, 11, 1), new DateOnly(2025, 11, 30), 52000, 29640, "57.0%", "Education"),
        new Election("e-005", "State Treasurer Ballot", "State-wide election for the position of State Treasurer.", "Closed", "Closed", new DateOnly(2025, 9, 5), new DateOnly(2025, 9, 20), 185000, 134420, "72.7%", "State"),
    };
}