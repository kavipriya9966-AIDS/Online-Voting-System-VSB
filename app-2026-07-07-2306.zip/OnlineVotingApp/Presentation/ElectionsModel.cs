namespace OnlineVotingApp.Presentation;

[Uno.Extensions.Reactive.ReactiveBindable(false)]
public partial record ElectionsModel
{
    public string PageTitle { get; } = "Elections";
    public string ActiveCount { get; } = "3";
    public string UpcomingCount { get; } = "2";
    public string ClosedCount { get; } = "9";

    public IReadOnlyList<Election> AllElections { get; } = new[]
    {
        new Election("e-001", "Presidential General Election 2026", "Cast your vote for the President of the Republic. This is the most significant national election determining the country's leadership for the next four years.", "Active", "Active", new DateOnly(2026, 3, 1), new DateOnly(2026, 3, 31), 240000, 112450, "46.9%", "National"),
        new Election("e-002", "City Council District 4", "Elect your local City Council representative for District 4, covering the northeast neighborhoods.", "Active", "Active", new DateOnly(2026, 3, 10), new DateOnly(2026, 3, 25), 18400, 6200, "33.7%", "Local"),
        new Election("e-003", "Referendum: Public Transit Expansion", "Vote on the proposed public transit infrastructure investment bill to expand rail and bus networks.", "Active", "Active", new DateOnly(2026, 3, 15), new DateOnly(2026, 4, 5), 95000, 31800, "33.5%", "Regional"),
        new Election("e-006", "State Governor Primary", "Nominate your party's candidate for the upcoming State Governor election in June 2026.", "Upcoming", "Upcoming", new DateOnly(2026, 4, 20), new DateOnly(2026, 5, 10), 310000, 0, "0.0%", "State"),
        new Election("e-007", "University Student Union President", "Students elect their representative for the Student Union Executive Council.", "Upcoming", "Upcoming", new DateOnly(2026, 4, 28), new DateOnly(2026, 5, 2), 12500, 0, "0.0%", "Education"),
        new Election("e-004", "School Board Election 2025", "Regional school board member elections across 6 districts.", "Closed", "Closed", new DateOnly(2025, 11, 1), new DateOnly(2025, 11, 30), 52000, 29640, "57.0%", "Education"),
        new Election("e-005", "State Treasurer Ballot", "State-wide election for the position of State Treasurer.", "Closed", "Closed", new DateOnly(2025, 9, 5), new DateOnly(2025, 9, 20), 185000, 134420, "72.7%", "State"),
        new Election("e-008", "Mayoral By-Election 2025", "Special by-election for the vacant Mayor seat in the Central District.", "Closed", "Closed", new DateOnly(2025, 7, 12), new DateOnly(2025, 7, 26), 41000, 22100, "53.9%", "Local"),
    };
}
