namespace OnlineVotingApp.Presentation;

public sealed partial class CandidatesPage : Page
{
    public CandidatesPage()
    {
        this.InitializeComponent();
        this.DataContext = new CandidatesModel();
    }
}
