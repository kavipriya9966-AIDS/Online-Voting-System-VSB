namespace OnlineVotingApp.Presentation;

[Uno.Extensions.Reactive.ReactiveBindable(false)]
public partial record ResultsModel
{
    public string PageTitle { get; } = "Election Results";
    public string TotalResultsPublished { get; } = "9";
    public string AverageVoterTurnout { get; } = "58.3%";

    public IReadOnlyList<ElectionResult> Results { get; } = new[]
    {
        new ElectionResult(
            "e-004",
            "School Board Election 2025",
            "Dr. Patricia Nguyen",
            "Independent",
            "38.4%",
            "57.0%",
            new DateOnly(2025, 12, 2),
            true,
            new[]
            {
                new Candidate("c-011", "e-004", "Dr. Patricia Nguyen", "Independent", "Board Member", "30-year educator, former principal of Jefferson Elementary.", 11388, "38.4%", ""),
                new Candidate("c-012", "e-004", "Marcus Webb", "Progressive Alliance", "Board Member", "Community advocate focusing on STEM and arts integration.", 10012, "33.8%", ""),
                new Candidate("c-013", "e-004", "Linda Osei", "Citizens First", "Board Member", "Parent liaison and curriculum reform advocate.", 8240, "27.8%", ""),
            }),
        new ElectionResult(
            "e-005",
            "State Treasurer Ballot",
            "Samuel Ortega",
            "Civic Reform Party",
            "52.6%",
            "72.7%",
            new DateOnly(2025, 9, 22),
            true,
            new[]
            {
                new Candidate("c-021", "e-005", "Samuel Ortega", "Civic Reform Party", "State Treasurer", "Former CFO with 20 years in public finance.", 70736, "52.6%", ""),
                new Candidate("c-022", "e-005", "Cynthia Blake", "Progressive Alliance", "State Treasurer", "State auditor champion of fiscal transparency.", 38822, "28.9%", ""),
                new Candidate("c-023", "e-005", "David Kim", "Unity Coalition", "State Treasurer", "Business economist advocating tax reform.", 24862, "18.5%", ""),
            }),
        new ElectionResult(
            "e-008",
            "Mayoral By-Election 2025",
            "Rachel Torres",
            "Unity Coalition",
            "49.8%",
            "53.9%",
            new DateOnly(2025, 7, 28),
            true,
            new[]
            {
                new Candidate("c-031", "e-008", "Rachel Torres", "Unity Coalition", "Mayor", "Urban planner and long-time community leader.", 11006, "49.8%", ""),
                new Candidate("c-032", "e-008", "Brian Foster", "Citizens First", "Mayor", "City council veteran with focus on public safety.", 9812, "44.4%", ""),
                new Candidate("c-033", "e-008", "Yuki Tanaka", "Independent", "Mayor", "Environmental lawyer supporting green city initiatives.", 1282, "5.8%", ""),
            }),
    };
}
