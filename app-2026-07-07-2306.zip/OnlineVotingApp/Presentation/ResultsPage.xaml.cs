namespace OnlineVotingApp.Presentation;

public sealed partial class ResultsPage : Page
{
    public ResultsPage()
    {
        this.InitializeComponent();
        this.DataContext = new ResultsModel();
    }
}
