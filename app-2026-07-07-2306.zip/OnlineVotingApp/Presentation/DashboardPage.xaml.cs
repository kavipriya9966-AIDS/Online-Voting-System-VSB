namespace OnlineVotingApp.Presentation;

public sealed partial class DashboardPage : Page
{
    public DashboardPage()
    {
        this.InitializeComponent();
        this.DataContext = new DashboardModel();
    }
}
