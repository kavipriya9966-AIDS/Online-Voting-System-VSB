namespace OnlineVotingApp.Presentation;

[Uno.Extensions.Reactive.ReactiveBindable(false)]
public partial record MainModel;