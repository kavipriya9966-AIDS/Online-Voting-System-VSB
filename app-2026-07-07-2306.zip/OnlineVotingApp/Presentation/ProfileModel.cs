namespace OnlineVotingApp.Presentation;

[Uno.Extensions.Reactive.ReactiveBindable(false)]
public partial record ProfileModel
{
    public string FullName { get; } = "Jordan Ellis";
    public string VoterIdLabel { get; } = "Voter ID: VTR-20261482";
    public string District { get; } = "District 4 — Northeast Region";
    public string RegistrationStatus { get; } = "Verified";
    public string TotalVotesCast { get; } = "7";
    public string ElectionsParticipated { get; } = "11";
    public string ParticipationRate { get; } = "63.6%";
    public string MemberSince { get; } = "March 2019";
    public string LastActivityDate { get; } = "March 10, 2026";

    public IReadOnlyList<VotingHistoryItem> VotingHistory { get; } = new[]
    {
        new VotingHistoryItem("e-004", "School Board Election 2025", "November 2025", "Voted", "Education"),
        new VotingHistoryItem("e-005", "State Treasurer Ballot", "September 2025", "Voted", "State"),
        new VotingHistoryItem("e-008", "Mayoral By-Election 2025", "July 2025", "Voted", "Local"),
        new VotingHistoryItem("e-009", "Regional Water Authority", "April 2025", "Voted", "Regional"),
        new VotingHistoryItem("e-010", "Congressional District 7", "November 2024", "Voted", "National"),
        new VotingHistoryItem("e-011", "Proposition 14 — Housing", "November 2024", "Voted", "State"),
        new VotingHistoryItem("e-012", "City Budget Referendum 2024", "March 2024", "Did Not Vote", "Local"),
    };

    public IReadOnlyList<ProfileSetting> AccountSettings { get; } = new[]
    {
        new ProfileSetting("Email Notifications", "Receive alerts for upcoming elections", true),
        new ProfileSetting("SMS Reminders", "Get text reminders before election day", true),
        new ProfileSetting("Result Alerts", "Be notified when election results are published", false),
        new ProfileSetting("Accessibility Mode", "High contrast and larger text display", false),
    };
}

public partial record VotingHistoryItem(
    string ElectionId,
    string ElectionTitle,
    string DateLabel,
    string VoteStatus,
    string Category);

public partial record ProfileSetting(
    string SettingName,
    string Description,
    bool IsEnabled);
