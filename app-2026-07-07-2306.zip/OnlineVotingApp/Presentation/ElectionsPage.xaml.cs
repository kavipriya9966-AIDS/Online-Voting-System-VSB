namespace OnlineVotingApp.Presentation;

public sealed partial class ElectionsPage : Page
{
    public ElectionsPage()
    {
        this.InitializeComponent();
        this.DataContext = new ElectionsModel();
    }
}
