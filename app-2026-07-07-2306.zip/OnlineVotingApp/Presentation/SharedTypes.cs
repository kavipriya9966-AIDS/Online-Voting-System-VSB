namespace OnlineVotingApp.Presentation;

public partial record Election(
    string Id,
    string Title,
    string Description,
    string Status,
    string StatusLabel,
    DateOnly StartDate,
    DateOnly EndDate,
    int TotalVoters,
    int VotesCast,
    string ParticipationPercent,
    string Category);

public partial record Candidate(
    string Id,
    string ElectionId,
    string Name,
    string Party,
    string Position,
    string Bio,
    int VoteCount,
    string VotePercent,
    string ImageUrl);

public partial record ElectionResult(
    string ElectionId,
    string ElectionTitle,
    string WinnerName,
    string WinnerParty,
    string WinnerVotePercent,
    string TurnoutPercent,
    DateOnly ResultDate,
    bool IsCertified,
    IReadOnlyList<Candidate> Candidates);
