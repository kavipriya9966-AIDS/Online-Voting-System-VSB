var UnoAppManifest = {
    displayName: "OnlineVotingApp"
}
